---
title: "Contact"
permalink: /contact/
---

**Email:** add-your-email-here  
**Affiliation:** Center for Computational Sciences (C3), Federal University of Rio Grande (FURG)  
**Location:** Rio Grande, Brazil

Also find me on:
- [Google Scholar](https://scholar.google.com/citations?user=iNuF4LMAAAAJ&hl=en)
- [ORCID](https://orcid.org/0000-0001-9159-2264)
- [ResearchGate](https://www.researchgate.net/profile/Eder-Mateus-Goncalves)
- [SciProfiles](https://sciprofiles.com/profile/edergoncalves)
- [Lattes](https://lattes.cnpq.br/8560050240967369)
