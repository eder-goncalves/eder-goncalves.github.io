---
title: "Projects"
permalink: /projects/
---

Use this page to highlight **selected projects** (not everything from the CV). A recommended structure:

- **Active Projects**
  - 2–5 bullets per project: goal, your role, partners, outcomes/TRL, funding.
- **Selected Past Projects**
- **Industry & Innovation**
  - EMBRAPII / iTEC-related initiatives, pilots, tech transfer.

*Tip:* Keep it concise and link to public artifacts (papers, code, demos) when possible.
