---
title: "Teaching"
permalink: /teaching/
---

Use this page to show your teaching portfolio and connect it to the research program.

## Courses
- *Tópicos Avançados em Sistemas Multiagente* — LLMs in MAS (Graduate/Undergraduate)
- *Add other courses and brief descriptions.*

## Advising
- Prospective students: describe research topics and how to apply/contact you.
