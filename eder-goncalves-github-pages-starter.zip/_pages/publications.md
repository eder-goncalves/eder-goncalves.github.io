---
title: "Publications (Selected)"
permalink: /publications/
---

This is a **curated** list. For the full list, see:
- [Google Scholar](https://scholar.google.com/citations?user=iNuF4LMAAAAJ&hl=en)
- [Lattes](https://lattes.cnpq.br/8560050240967369)
- [ORCID](https://orcid.org/0000-0001-9159-2264)

## Selected Publications
- *Add 5–10 key papers here (title, venue, year, links).*
